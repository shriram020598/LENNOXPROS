package com.test.utilities;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Datepicker {
 
	static WebDriver driver;
	
	
	

	
	public void ddmmyyy()
	{	
	driver.findElement(By.id("selectcalender")).click();
	new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("ui-datepicker-calendar"))); 
		
	selectDate("22", "May", "2021");
	
	
	}
	public static String[] getMonthYear(String monthYearVal)
	{
		return monthYearVal.split("-");
		
	}
	
	
		public static  void selectDate(String exDay,String exMonth,String exYear)
		{
			
			String monthYearVal=driver.findElement(By.className("ui-datepicker-title")).getText();
			System.out.println(monthYearVal);
			
			while (!(getMonthYear(monthYearVal)[0].equals(exMonth)
					&&
					getMonthYear(monthYearVal)[1].equals(exYear))) {
				driver.findElement(By.xpath("//a[@title='Next']")).click();
				driver.findElement(By.className("ui-datepicker-title")).getText();
				
			}
					driver.findElement(By.xpath("//a[text()='"+exDay+"']")).click();
					
		}
}
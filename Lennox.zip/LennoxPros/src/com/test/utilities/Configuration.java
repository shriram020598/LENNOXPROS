package com.test.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Configuration {

	Properties pro;

	public Configuration() {

		File src = new File("./properties/config.properties");

		try {
			FileInputStream fis = new FileInputStream(src);

			pro = new Properties();

			pro.load(fis);
		} catch (Exception e) {

			System.out.println("Not able to load config file>>" + e.getMessage());

		} 

	}

	public String getDataFromConfig(String keyToSearch) {
		
		return pro.getProperty(keyToSearch);
		
	}
	
	public String getBrowser() {
		
		return pro.getProperty("Browser");
		
	}
	
	public String getStagingURL() {
		
		return pro.getProperty("qaUrl");
		
	}
	
	public String getusername()
	{
		return pro.getProperty("username");
	}
	
	public String getpassword()
	{
		return pro.getProperty("password");
	}
	
	public String getexcelpath()
	{
		return pro.getProperty("excelpath");
	}
	
	public String getreportpath()
	{
		return pro.getProperty("reportpath");
	}
	public String uploadpath()
	{
		return pro.getProperty("upload");
	}
	public String imageuploadpath()
	{
		return pro.getProperty("imageupload");
	}
	public String driverpath()
	{
		return pro.getProperty("chromedriver");
	}
	public String ScreenshotSuccess()
	{
		return pro.getProperty("Screenshot-Successpath");
	}
	public String ScreenshotFailure()
	{
		return pro.getProperty("Screenshot-Failurepath");
	}
}


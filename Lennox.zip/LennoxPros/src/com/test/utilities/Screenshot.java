package com.test.utilities;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class Screenshot {
	
	Configuration config=new Configuration();

	public File takeScreenShotDetails(WebDriver webDriver) {
		TakesScreenshot takesScreenshot = (TakesScreenshot) webDriver;
		File file = takesScreenshot.getScreenshotAs(OutputType.FILE);
		return file;
	}
	// Used to store all the screenshots on successful 
		public void takeScreenshotOnSuccess(WebDriver webDriver, int successCount) {
			File file = takeScreenShotDetails(webDriver);
			try {
				FileHandler.copy(file,
						new File(config.ScreenshotSuccess() + successCount + "+.png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}

		// Used to store all the screenshots on failure 
		public void takeScreenshotOnFailure(WebDriver webDriver, int failureCount) {
			File file = takeScreenShotDetails(webDriver);
			try {
				FileHandler.copy(file,
						new File(config.ScreenshotFailure() + failureCount + "+.png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
	
}}

package com.test.Pom;

import java.sql.Driver;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class NavigateToLead {
	WebDriver driver;

	
	public NavigateToLead(WebDriver driver)
	{
		this.driver=driver;
	}


	
	@FindBy(xpath = "//*[@id=\"page\"]/div[1]/div/div[1]/a" ) WebElement dropdown;
	@FindBy(xpath = "//*[@id=\"page\"]/div[1]/div/div[3]/div[3]/div/div[5]/a") WebElement salestools;
	@FindBy(xpath="//a[contains(text(),'Build a Proposal')]") WebElement buildproposal;
	@FindBy(linkText = "SELECT LEAD") WebElement selectLead;
	
	
	
	
	
	
	public void NavigatePage() throws InterruptedException
	{
		dropdown.sendKeys(Keys.ENTER);
		salestools.click();
		buildproposal.click();
		Thread.sleep(2000);
		selectLead.sendKeys(Keys.ENTER);
		
	}
	
	
	
	
	
	
}

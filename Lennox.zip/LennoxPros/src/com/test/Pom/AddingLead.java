package com.test.Pom;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddingLead {
WebDriver driver;
	
	
	public AddingLead(WebDriver driver)
	{
		this.driver=driver;

	}
	


	@FindBy(linkText = "ADD LEAD") WebElement addlead;
	@FindBy(id = "lastName") WebElement lname;
	@FindBy(id = "phNo") WebElement phno;
	@FindBy(id = "email") WebElement mail;



	//date and timing
	@FindBy(id = "calender1") WebElement calender ;
	@FindBy(xpath="//a[contains(text(),'21')]")WebElement pickdate;



	//document 
	@FindBy(xpath = "//p[contains(text(),'Add Document')]") WebElement addocument;
	@FindBy(id = "multipleFileSelect-1") WebElement selectfile;
	@FindBy(xpath = "//*[@id=\"modal-edit-lead-add-doc\"]/div/div/div[6]/a[2]") WebElement addtolead;


	//image
	@FindBy(id = "multipleImageSelect[0]") WebElement chooseimage;
	@FindBy(xpath = "//button[@id='btn-addLeadsForm']") WebElement savelead;

	



	public void addingtoleadpage(String firstname,String lastname,String phoneno,String email,String dateofvisit,String attendtiming) throws InterruptedException
	{
		addlead.sendKeys(Keys.ENTER);
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement fname = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("firstName")));
		fname.sendKeys(firstname);
		Thread.sleep(1000);
		lname.sendKeys(lastname);
		phno.sendKeys(phoneno);
		Thread.sleep(1000);
		mail.sendKeys(email);
		Thread.sleep(1000);
		calender.click();
		pickdate.click();
		
		
	}
	
	





	public void uploaddocument(String upload,String imageupload) throws InterruptedException
	{
		addocument.click();
		Select drpdown = new Select(driver.findElement(By.name("documents[1].documentType")));
		drpdown.selectByVisibleText("OTHER");
		Thread.sleep(2000);
		selectfile.sendKeys(upload);
		addtolead.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		chooseimage.sendKeys(imageupload);
		savelead.sendKeys(Keys.ENTER);

	}
	
	
	
	
	public void verifyleadsaved()
	{
		String expectedHeading = "Lead Saved Successfully";
		String heading=driver.findElement(By.xpath("//li[contains(text(),'Lead Saved Successfully')]")).getText();
		if(expectedHeading.equalsIgnoreCase(heading))
          	System.out.println("The verification of Lead is Successful --- "+heading);
    	else
          	System.out.println("The verification of Lead is not Successful --- "+heading);
	}
	}
	



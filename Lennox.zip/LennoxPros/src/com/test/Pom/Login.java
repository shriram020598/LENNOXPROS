package com.test.Pom;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {

	WebDriver driver;

	public Login(WebDriver driver) {

		this.driver=driver;
	}


	@FindBy(css = "a.login-link.btn.NEEDS_AUTHENTICATION") WebElement signIn;
	@FindBy(id = "j_password") WebElement Password;
	@FindBy(id = "loginSubmit") WebElement loginbutton;

	
	public void loginpage(String username,String password) throws InterruptedException
	{

		signIn.sendKeys(Keys.ENTER);
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement UserName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("j_username")));
		UserName.sendKeys(username);
		Password.sendKeys(password);
		Thread.sleep(2000);
		loginbutton.click();

	}






}

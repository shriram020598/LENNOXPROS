package com.test.main;

import java.io.IOException;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.test.utilities.Configuration;
import com.test.utilities.ExtentReporterNG;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import com.test.Pom.AddingLead;
import com.test.Pom.Login;
import com.test.Pom.NavigateToLead;
import com.test.utilities.BrowsersSetUp;

import com.test.utilities.Screenshot;
import com.test.utilities.ReadingExcelData;

public class Main extends Screenshot {
	private ExtentReports extent;
	ExtentReporterNG reporter = new ExtentReporterNG();
	private int successCount;
	private int failureCount;
	public static WebDriver driver;
	String fname;
	String lname;
	String phno;
	String mail;
	String date;
	String timing;
	
	Configuration config = new Configuration();

	public Main MainObject() {
		Main page = new Main();
		return page;
	}

	
	@BeforeClass
	public void setup() {

		driver = new BrowsersSetUp().setUpBrowser(config.getBrowser(), config.getStagingURL());

	}
	

	@DataProvider(name = "data")
	public Object[][] readExcelData() {
		Object[][] objectData = null;
		try {
			objectData = new ReadingExcelData().webPage();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objectData;
	}

	
	@Test(priority = 2, dataProvider = "data")
	public void Signup(Object... objectArray) throws InterruptedException, IOException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.loginpage((String) objectArray[0], (String) objectArray[1]);

		try {
			successCount = successCount + 1;
			MainObject().takeScreenshotOnSuccess(driver, successCount);
		} catch (Exception e) {
			failureCount = failureCount + 1;
			MainObject().takeScreenshotOnFailure(driver, failureCount);
		}

	}

	
	@Test(priority = 3, dataProvider = "data")
	public void navigate(Object... objectArray) throws InterruptedException {
		NavigateToLead Navi = PageFactory.initElements(driver, NavigateToLead.class);
		Navi.NavigatePage();
		// list.onTestFailure(null, "NavigateToLead");
		try {
			successCount = successCount + 1;
			MainObject().takeScreenshotOnSuccess(driver, successCount);
		} catch (Exception e) {
			failureCount = failureCount + 1;
			MainObject().takeScreenshotOnFailure(driver, failureCount);
		}

	}

	
	@Test(priority = 4, dataProvider = "data")
	public void Addlead(Object... objectArray) throws InterruptedException {
		// search = (String) objectArray[4];
		fname = (String) objectArray[2];
		lname = (String) objectArray[3];
		phno = (Long) objectArray[4] + "";
		mail = (String) objectArray[5];
		date = (String) objectArray[6];
		timing = (Long) objectArray[7] + "";
		AddingLead adlead = PageFactory.initElements(driver, AddingLead.class);
		adlead.addingtoleadpage(fname, lname, phno, mail, date, timing);
		adlead.uploaddocument(config.uploadpath(), config.imageuploadpath());
		
		adlead.verifyleadsaved();
		try {
			successCount = successCount + 1;
			MainObject().takeScreenshotOnSuccess(driver, successCount);
		} catch (Exception e) {
			failureCount = failureCount + 1;
			MainObject().takeScreenshotOnFailure(driver, failureCount);
		}

		driver.close();
	}

	@AfterSuite
	public void teardown() {
		
		extent.flush();
	}

}
